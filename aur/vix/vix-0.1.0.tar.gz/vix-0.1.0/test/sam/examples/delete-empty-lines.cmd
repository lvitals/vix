x g/^$/ d
