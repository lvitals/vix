Unit Test for Vix' Lua API
--------------------------

The test-suite is based on the [busted][] unit testing framework.

Each `*.lua` file is sourced from a new `vix` instance which loads the
correspending `*.in` file.

Use the `test.sh` shell script to run an individual test or type `make`
to run all tests.

[busted]: https://lunarmodules.github.io/busted
